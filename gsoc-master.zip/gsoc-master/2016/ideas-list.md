# Ideas Pages

This is the home page of projects ideas of NumFocus for Google Summer of Code 2016.
Since NumFocus is a umbrella organization you will only find links to the ideas
page of each organization under NumFocus umbrella at this page.

- biocore: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-biocore.md
- bokeh: https://github.com/bokeh/bokeh/wiki/GSOC-2016-Ideas
- DyND: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-dynd.md
- EcoData Retriever: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-ecodata-retriever.md
- Gensim: https://github.com/piskvorky/gensim/wiki/Student-Projects
- JuliaOpt: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-juliaopt.md
- JuliaQuantum: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-juliaquantum.md
- matplotlib: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-matplotlib.md
- Pandas: https://github.com/pydata/pandas/wiki/Google-Summer-of-Code
- Software Carpentry: https://github.com/numfocus/gsoc/blob/master/2016/ideas-list-swc.md
