# Ideas Pages

- Julia: https://github.com/numfocus/gsoc/blob/master/2015/ideas-list-julia.md
- Software Carpentry: https://github.com/numfocus/gsoc/blob/master/2015/ideas-list-swc.md
- SymPy: https://github.com/sympy/sympy/wiki/GSoC-2015-Ideas
