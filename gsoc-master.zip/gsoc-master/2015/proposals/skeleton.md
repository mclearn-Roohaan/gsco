# Title

## Abstract

## Technical Details

## Schedule of Deliverables

### May 25th -  June 7th

**You need to accomplish this to mid-term.**

### June 8th - June 21th

**You need to accomplish this to mid-term.**

### June 22th - July 5th

### July 6th - July 19th

### July 20th - August 2rd

### August 3rd - August 16th

### August 17th - August 21th 19:00 UTC

**Week to scrub code, write tests, improve documentation, etc.**

## Future works

## Open Source Development Experience

## Academic Experience

## Why this project?

## Appendix
