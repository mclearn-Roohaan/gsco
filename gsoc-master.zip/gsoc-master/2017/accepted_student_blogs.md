# Google Summer of Code 2017

## Data Retriever

| Student             | Blog link                                     |
| -------             | ---------                                     |
| Shivam Negi         | https://medium.com/data-retriever-gsoc17      |

## Matplotlib

| Student             | Blog link                                     |
| -------             | ---------                                     |
| Harshit Patni       | https://patniharshit.github.io/               |
| Kaitlyn Chait       | https://katierose1029.github.io/              |

## MDAnalysis

| Student             | Blog link                                     |
| -------             | ---------                                     |
| Utkarsh Bansal      | http://utkarshbansal.me                       |

## FEniCS

| Student             | Blog link                                     |
| -------             | ---------                                     |
| Ivan Yashchuk       | https://ivanyashchuk.github.io/               |
| Michal Habera       | http://karlin.mff.cuni.cz/%7Ehabera/?p=gsoc17 |

## PyMC3

| Student             | Blog link                                     |
| -------             | ---------                                     |
| Maxim Kochurov      | https://ferrine.github.io                     |
| Bhargav Srinivasa   | https://summerofcode2017.wordpress.com/       |
| Bill William Engels | http://bwengals.github.io/                    |

## Gensim

| Student           | Blog link                                                                                                          |
| -------           | ---------                                                                                                          |
| Chinmaya Pancholi | https://chinmayapancholi13.github.io/                                                                              |
| Prakhar Pratyush  | https://rare-technologies.com/google-summer-of-code-2017-live-blog-performance-improvement-in-gensim-and-fasttext/ |
| Parul Sethi       | https://rare-technologies.com/gsoc17-training-and-topic-visualizations/                                                                                  |

