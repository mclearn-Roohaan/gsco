# Ideas Pages

This is the home page of projects ideas of NumFocus for Google Summer of Code 2017.
Since NumFOCUS is a umbrella organization you will only find links to the ideas
page of each organization under NumFocus umbrella at this page.

- conda-forge https://docs.google.com/document/d/1KSQvcP3Hxr60IhV-_dcGIb4IkmAEeAXNIqdX_2sqYoM
- Data Retriever https://github.com/weecology/retriever/wiki/GSoC-2017-Project-Ideas
- FEniCS https://github.com/numfocus/gsoc/blob/master/2017/ideas-list-fenics.md
- gensim https://github.com/RaRe-Technologies/gensim/wiki/GSOC-2017-project-ideas
- nteract https://github.com/nteract/nteract/wiki/GSoC-2017-Ideas
- matplotlib https://github.com/numfocus/gsoc/blob/master/2017/ideas-list-matplotlib.md
- MDAnalysis https://github.com/MDAnalysis/mdanalysis/wiki/GSoC-2017-Project-Ideas
- PyMC3 https://github.com/pymc-devs/pymc3/wiki/GSoC-2017-projects
- Stan https://github.com/numfocus/gsoc/blob/master/2017/ideas-list-stan.md


See the [README](https://github.com/numfocus/gsoc/blob/master/READMD.md) for contact information of each org.
