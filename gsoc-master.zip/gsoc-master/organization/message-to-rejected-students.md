As you can see above, your proposal to NumFOCUS umbrella was
not accepted for the Google Summer of Code this year. There
were a lot of excellent applications but resources, the
number of slots Google gave us, are limited and many good
applications had to be rejected.

You helped us a lot just by submitting such a good proposal.
That helped to raise the bar. Thanks for your time and
effort.

We hope that you learned something new. We'd like to have
you around, and any contribution you make to any of the
projects under NumFOCUS umbrella is very much appreciated
(bug reports, participating on the list, patches, code). But
of course, we understand you may not have time if you find
some other job over the summer.

We liked that you discussed your proposal with us. If you
decide to work on your project anyway, We are sure you'll
find many people willing to help out.

We encourage you to try again next year. Experience has
shown that students who are involved in the project early
are more likely to be accepted, so if you do plan to do
this, I recommend that you continue your contributions to
the project.

Thanks and good luck!

NumFOCUS Administrators for GSoC
