## NumFOCUS Application Materials

- [NumFOCUS Operation][OP]
- [NumFOCUS Profile][OA]
- [NumFOCUS Questionnaire][OQ]
- [NumFOCUS Team][OT]
- [Organization Stipend][stipend]
- [Mentor Summit][summit]

For informations, check
http://en.flossmanuals.net/melange/org-application-period/.


[OA]: profile.md
[OP]: operations.md
[OQ]: questionnaire.md
[OT]: team.md
[stipend]: stipend.md
[summit]: summit.md
