# Organization Stipend

At the end of the Program,
mentoring organizations,
**in this case NumFOCUS**,
may receive a $500 USD stipend per student mentored.

NumFOCUS agrees to pass along stipend per student mentored
to the project who mentored the student.

## Fiscally Sponsored Projects

Fiscally sponsored projects will have their stipend
transfered to their bank account
as soon as NumFOCUS receive Google's payment,
what normally happens in December.

## Affiliated Projects

Affiliated projects will be contacted by NumFOCUS
after NumFOCUS receive Google's payment
with a bank account enquire.

## Non Affiliated Projects

Non affiliated projects will be contacted by NumFOCUS
after NumFOCUS receive Google's payment
with a bank account enquire.
