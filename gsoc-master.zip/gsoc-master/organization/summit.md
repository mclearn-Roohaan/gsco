# Mentor Summit

Every year Google promote a Summit
and each [**mentoring**] organization,
**in this case only NumFOCUS**,
may send two (2) members to the Mentor Summit.

NumFOCUS will nominate as Summit ambassador
the lead administrator of the current year
**and** the lead administrator of following year.
If the current lead administrator
are going to continue on that role on the following year
then one of the other administrator can be invited
by the lead administrator.

Any mentor interested to attend the Summit
**in case any of the administrators**
aren't able to attend the event
can email at any time the lead administrator
manifesting their interest.
**The lead administrator will select
at his/her own discretion who will attend
the Summit on his/her place.**
