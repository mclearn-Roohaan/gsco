# Contributing

Please check

- [Contributing Guide for Students][CS]
- [Contributing Guide for Mentors][CM]

[CM]: CONTRIBUTING-mentors.md
[CS]: CONTRIBUTING-students.md
