
# Ideas Pages

This is the home page of projects ideas of NumFocus for Google Summer of Code 2018.
Since NumFOCUS is an umbrella organization you will only find links to the ideas
page of each organization under the NumFocus umbrella at this page.

- Cantera https://github.com/Cantera/cantera/wiki/GSoC-2018-Ideas
- conda-forge https://docs.google.com/document/d/1KSQvcP3Hxr60IhV-_dcGIb4IkmAEeAXNIqdX_2sqYoM
- Data Retriever https://github.com/weecology/retriever/wiki/GSoC-2018-Project-Ideas
- FEniCS Project https://github.com/numfocus/gsoc/blob/master/2018/ideas-list-fenics.md
- MDAnalysis https://github.com/MDAnalysis/mdanalysis/wiki/GSoC-2018-Project-Ideas
- yt https://github.com/yt-project/gsoc-2018
- PyMC3 https://github.com/pymc-devs/pymc3/wiki/GSoC-2018-projects
- gensim  https://github.com/RaRe-Technologies/gensim/wiki/GSoC-2018-project-ideas
- Julia https://julialang.org/soc/ideas-page.html
- Shogun https://github.com/shogun-toolbox/shogun/wiki/Google-Summer-of-Code-2018-Projects

See the [README](https://github.com/numfocus/gsoc/blob/master/README.md) for contact information of each org.
